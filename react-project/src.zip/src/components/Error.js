function Error() {
    return (
      <div>
    
      </div>
    );
  }
  
  export default Error;